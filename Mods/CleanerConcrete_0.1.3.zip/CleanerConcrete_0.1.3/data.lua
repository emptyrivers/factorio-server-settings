data.raw.tile['stone-path'].decorative_removal_probability = 1 -- all from factorio/data/base/prototypes/tile/tiles.lua let me know if new tiles need it
data.raw.tile['concrete'].decorative_removal_probability = 1
data.raw.tile['hazard-concrete-right'].decorative_removal_probability = 1
data.raw.tile['hazard-concrete-left'].decorative_removal_probability = 1
